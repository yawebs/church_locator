<?php
session_start();
if (isset($_SESSION['this-is-an-incoming-super-admin'])) {

    if (isset($_POST['upload-product'])) {


        require '../../../includes/dbh.inc.php';
        require '../../../func/prequest.php';

        $_SESSION['error-product'] = "";
        $_SESSION['success'] = "";
        $file = $_FILES['file'];
        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES['file']['size'];
        $fileError = $_FILES['file']['error'];
        $fileType = $_FILES['file']['type'];
        $productName = $_POST['product-name'];
        $productLink = $_POST['product-link'];
        $productDesc = $_POST['product-desc'];
        $allowed = array('jpg', 'jpeg', 'png');

        if (empty($fileName)) {

            $_SESSION['error-product'] = "Product Image Required";
            header("Location:../products-upload.php");
            exit();
        } else if (empty($productName)) {
            $_SESSION['error-product'] = "Product Name Required";
            header("Location:../products-upload.php");
            exit();
        } else if (empty($productDesc)) {
            $_SESSION['error-product'] = "Product Description Required";
            header("Location:../products-upload.php");
            exit();
        } else if (empty($productLink)) {
            $_SESSION['error-product'] = "Product Link Required";
            header("Location:../products-upload.php");
            exit();
        } else {
            $fileExt = explode('.', $fileName);
            $fileActualExt = strtolower(end($fileExt));


            if (in_array($fileActualExt, $allowed)) {

                if ($fileError == 0) {
                    if ($fileSize < 700000) {

                        $imageNewName = uniqid('', true) . "." . $fileActualExt;
                        $fileDestionation = "../assets/img/products/" . $imageNewName;

                        $query = $pdo->prepare("INSERT INTO products (product_name, product_link,product_desc, product_img) VALUES (?,?,?,?)");
                        $query->execute([$productName, $productLink, $productDesc, $imageNewName]);

                        move_uploaded_file($fileTmpName, $fileDestionation);
                        $message = $productName . ' has just been uploaded, its a new product of ABiTNetwork ' . $productLink;
                        $addNotificationRequest = new PaymentRequest;
                        $addnotification = $addNotificationRequest->addNotification(0, $message, 'new product');

                        $_SESSION['success-product'] = "Product Successfully Added ";
                        header("Location:../products-upload.php");
                        exit();
                    } else {
                        $_SESSION['error-product'] = "Image must be less than 4mb ";
                        header("Location:../products-upload.php");
                        exit();
                    }
                } else {
                    $_SESSION['error-product'] = "There was an Error Uploading this file, Please try again";
                    header("Location:../products-upload.php");
                    exit();
                }
            } else {
                $_SESSION['error-product'] = "only Jpg,jpeg,png are supported";
                header("Location:../products-upload.php");
                exit();
            }
        }
    } else {


        header("Location: ../products-upload.php");
        exit();
    }
} else {


    header("Location: ../../../index.php");
    exit();
}
